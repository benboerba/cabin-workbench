import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { and, eq, gt, lt } from "drizzle-orm";
import { cookies } from "next/headers";
import { getDb } from "../../db";
import { authSessions, users } from "../../db/schema";
import { getAppEdition, isLocalEdition, type AppEdition } from "./app-edition";

const SESSION_COOKIE = "cabin_session";
const GUEST_COOKIE = "cabin_guest";
const SESSION_LIFETIME_MS = 30 * 24 * 60 * 60 * 1000;

export type AppUser = {
  userId: string;
  displayName: string;
  email: string;
  fullName: string | null;
  onboardingVersion: number;
  edition: AppEdition;
};

const LOCAL_USER_ID = "local-personal-workbench";
const LOCAL_USER_EMAIL = "local@cabin.local";

export function normalizeEmail(value: unknown): string | null {
  if (typeof value !== "string") return null;
  const email = value.trim().toLowerCase();
  if (email.length < 3 || email.length > 254) return null;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return null;
  return email;
}

export function validatePassword(value: unknown): value is string {
  return typeof value === "string" && value.length >= 8 && value.length <= 128;
}

export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const derived = await derivePassword(password, salt, 64);
  return `scrypt-v1$${salt.toString("base64url")}$${derived.toString("base64url")}`;
}

export async function verifyPassword(
  password: string,
  storedHash: string,
): Promise<boolean> {
  const [version, saltValue, hashValue] = storedHash.split("$");
  if (version !== "scrypt-v1" || !saltValue || !hashValue) return false;

  try {
    const salt = Buffer.from(saltValue, "base64url");
    const expected = Buffer.from(hashValue, "base64url");
    const actual = await derivePassword(password, salt, expected.length);
    return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

export async function createSession(userId: string): Promise<void> {
  const rawToken = randomBytes(32).toString("base64url");
  const tokenHash = hashSessionToken(rawToken);
  const now = new Date();
  const expiresAt = new Date(now.getTime() + SESSION_LIFETIME_MS);
  const db = getDb();

  await db.delete(authSessions).where(lt(authSessions.expiresAt, now.toISOString()));
  await db.insert(authSessions).values({
    tokenHash,
    userId,
    expiresAt: expiresAt.toISOString(),
    createdAt: now.toISOString(),
  });

  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, rawToken, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE !== "false" && process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  cookieStore.set(GUEST_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE !== "false" && process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(0),
  });
}

export async function destroySession(): Promise<void> {
  const cookieStore = await cookies();
  const rawToken = cookieStore.get(SESSION_COOKIE)?.value;
  if (rawToken) {
    await getDb()
      .delete(authSessions)
      .where(eq(authSessions.tokenHash, hashSessionToken(rawToken)));
  }
  cookieStore.set(SESSION_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE !== "false" && process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(0),
  });
  cookieStore.set(GUEST_COOKIE, "", {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.COOKIE_SECURE !== "false" && process.env.NODE_ENV === "production",
    path: "/",
    expires: new Date(0),
  });
}

export async function getSessionUser(): Promise<AppUser | null> {
  if (isLocalEdition()) return getLocalUser();

  const cookieStore = await cookies();
  const rawToken = cookieStore.get(SESSION_COOKIE)?.value;
  if (!rawToken) return cookieStore.get(GUEST_COOKIE)?.value === "1" ? getGuestUser() : null;

  const now = new Date().toISOString();
  const [row] = await getDb()
    .select({
      userId: users.id,
      displayName: users.displayName,
      email: users.email,
      onboardingVersion: users.onboardingVersion,
      expiresAt: authSessions.expiresAt,
    })
    .from(authSessions)
    .innerJoin(users, eq(users.id, authSessions.userId))
    .where(
      and(
        eq(authSessions.tokenHash, hashSessionToken(rawToken)),
        gt(authSessions.expiresAt, now),
      ),
    )
    .limit(1);

  if (!row) return cookieStore.get(GUEST_COOKIE)?.value === "1" ? getGuestUser() : null;
  return {
    userId: row.userId,
    displayName: row.displayName,
    email: row.email,
    fullName: row.displayName,
    onboardingVersion: row.onboardingVersion,
    edition: getAppEdition(),
  };
}

function getGuestUser(): AppUser {
  return {
    userId: "guest-read-only",
    displayName: "游客",
    email: "guest@cabin.local",
    fullName: "游客",
    onboardingVersion: 1,
    edition: "guest",
  };
}

async function getLocalUser(): Promise<AppUser> {
  const db = getDb();
  const displayName = (process.env.LOCAL_DISPLAY_NAME?.trim() || "我的木屋").slice(0, 30);

  await db
    .insert(users)
    .values({
      id: LOCAL_USER_ID,
      email: LOCAL_USER_EMAIL,
      displayName,
      passwordHash: "local-edition-no-password",
    })
    .onConflictDoNothing();

  const [row] = await db
    .select({
      userId: users.id,
      displayName: users.displayName,
      email: users.email,
      onboardingVersion: users.onboardingVersion,
    })
    .from(users)
    .where(eq(users.id, LOCAL_USER_ID))
    .limit(1);

  if (!row) throw new Error("无法初始化个人本地版数据");
  return {
    userId: row.userId,
    displayName: row.displayName,
    email: row.email,
    fullName: row.displayName,
    onboardingVersion: row.onboardingVersion,
    edition: "local",
  };
}

export function displayNameFromEmail(email: string): string {
  const localPart = email.split("@")[0]?.trim();
  return (localPart || "木屋住客").slice(0, 30);
}

function hashSessionToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

function derivePassword(
  password: string,
  salt: Buffer,
  length: number,
): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scrypt(
      password,
      salt,
      length,
      { N: 16_384, r: 8, p: 1, maxmem: 64 * 1024 * 1024 },
      (error, derivedKey) => {
        if (error) reject(error);
        else resolve(derivedKey);
      },
    );
  });
}
